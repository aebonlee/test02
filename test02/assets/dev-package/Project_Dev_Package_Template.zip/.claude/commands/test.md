# Test Command

Run all tests and report results.

## Instructions
1. Run unit tests
2. Run integration tests
3. Check test coverage
4. Report failures with details
5. Suggest fixes for failing tests
